import React from 'react';

const features = [
  {
    title: 'Unified data layer',
    badge: 'Data',
    description:
      'Satukan event product, billing, dan marketing ke satu sumber kebenaran tanpa pipeline yang rumit.',
  },
  {
    title: 'Realtime, bukan per-batch',
    badge: 'Realtime',
    description:
      'Stream data dalam hitungan detik, cocok untuk tim growth, ops, dan finance yang butuh respon cepat.',
  },
  {
    title: 'Insight dengan AI',
    badge: 'AI',
    description:
      'Deteksi anomali, rekomendasi eksperimen, dan alert otomatis yang bisa diatur sesuai konteks bisnis.',
  },
];

function Features() {
  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-brand-300">
            Fitur utama
          </p>
          <h2 className="mt-2 text-2xl font-semibold tracking-tight sm:text-3xl">
            Dibangun untuk tim data modern.
          </h2>
        </div>
        <p className="max-w-md text-xs text-slate-300 sm:text-sm">
          Dari startup sampai enterprise, NovaSuite membantu menyatukan dashboard yang biasanya tersebar di banyak tool. Plug-and-play ke stack yang sudah ada.
        </p>
      </div>
      <div className="grid gap-4 md:grid-cols-3">
        {features.map(feature => (
          <div
            key={feature.title}
            className="glass-panel flex flex-col justify-between rounded-2xl p-4 shadow-soft-glow/0 transition hover:shadow-soft-glow"
          >
            <div className="flex items-center gap-2 text-xs">
              <span className="inline-flex items-center rounded-full bg-brand-500/10 px-2 py-0.5 text-[11px] font-semibold text-brand-200">
                {feature.badge}
              </span>
              <span className="text-[11px] text-slate-400">Enterprise ready</span>
            </div>
            <div className="mt-4 space-y-2">
              <h3 className="text-sm font-semibold text-slate-50 sm:text-base">
                {feature.title}
              </h3>
              <p className="text-xs text-slate-300 sm:text-sm">
                {feature.description}
              </p>
            </div>
            <div className="mt-4 flex items-center justify-between text-[11px] text-slate-400">
              <span>SSO  b7 RBAC  b7 Audit log</span>
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Features;
