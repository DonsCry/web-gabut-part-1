import React from 'react';

function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-slate-800/80 bg-slate-950/80">
      <div className="mx-auto flex max-w-6xl flex-col gap-4 px-4 py-6 text-[11px] text-slate-400 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-2">
          <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-gradient-to-tr from-brand-400 to-brand-600">
            <span className="text-xs font-bold text-slate-950">N</span>
          </div>
          <span>NovaSuite Analytics</span>
          <span className="text-slate-600"> b7</span>
          <span> a9 {year}</span>
        </div>
        <div className="flex flex-wrap gap-3">
          <a href="#hero" className="hover:text-slate-200">
            Produk
          </a>
          <a href="#pricing" className="hover:text-slate-200">
            Harga
          </a>
          <a href="#faq" className="hover:text-slate-200">
            Dokumentasi
          </a>
          <a href="#hero" className="hover:text-slate-200">
            Status sistem
          </a>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
