import React from 'react';

const customers = [
  {
    name: 'AuroraPay',
    role: 'VP Data',
    quote:
      'NovaSuite menurunkan waktu analisis dari jam menjadi menit. Tim kami akhirnya bisa fokus ke eksperimen, bukan bersih-bersih data.',
  },
  {
    name: 'Northwind Mobility',
    role: 'Head of Product',
    quote:
      'Dashboard operasional yang biasanya kami rakit sendiri kini bisa dibuat dalam hitungan hari, bukan bulan.',
  },
];

function Showcase() {
  return (
    <div className="grid gap-8 md:grid-cols-[minmax(0,1.2fr)_minmax(0,1fr)] md:items-start">
      <div className="space-y-4">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-brand-300">
          Realtime overview
        </p>
        <h2 className="text-2xl font-semibold tracking-tight sm:text-3xl">
          Satu layar untuk memantau seluruh perjalanan user.
        </h2>
        <p className="max-w-xl text-xs text-slate-300 sm:text-sm">
          Hubungkan event tracking, subs billing, dan support ticket untuk melihat konteks lengkap setiap pelanggan. Tanpa perlu lompat-lompat antar tool.
        </p>
        <div className="grid gap-4 sm:grid-cols-3">
          <div className="glass-panel rounded-2xl p-4">
            <div className="text-xs text-slate-400">MRR</div>
            <div className="mt-2 text-2xl font-semibold text-slate-50">+18.3%</div>
            <p className="mt-2 text-[11px] text-emerald-300">
              Dari cohort pelanggan baru 90 hari terakhir.
            </p>
          </div>
          <div className="glass-panel rounded-2xl p-4">
            <div className="text-xs text-slate-400">Churn risk</div>
            <div className="mt-2 flex items-baseline gap-1">
              <span className="text-2xl font-semibold text-slate-50">2.4%</span>
              <span className="text-[11px] text-emerald-300">turun 31%</span>
            </div>
            <p className="mt-2 text-[11px] text-slate-300">
              Model scoring churn dengan data produk + billing.
            </p>
          </div>
          <div className="glass-panel rounded-2xl p-4">
            <div className="text-xs text-slate-400">Alert otomatis</div>
            <div className="mt-2 text-2xl font-semibold text-slate-50">120+</div>
            <p className="mt-2 text-[11px] text-slate-300">
              Alert granular ke Slack, Email, dan PagerDuty.
            </p>
          </div>
        </div>
      </div>
      <div className="space-y-4">
        <div className="glass-panel rounded-2xl p-4">
          <div className="text-xs text-slate-400">Dipercaya oleh tim di</div>
          <div className="mt-2 flex flex-wrap gap-2 text-xs font-medium text-slate-200">
            <span className="rounded-full bg-slate-900/80 px-3 py-1">Fintech</span>
            <span className="rounded-full bg-slate-900/80 px-3 py-1">SaaS B2B</span>
            <span className="rounded-full bg-slate-900/80 px-3 py-1">Marketplace</span>
            <span className="rounded-full bg-slate-900/80 px-3 py-1">Logistics</span>
          </div>
          <div className="mt-4 space-y-3">
            {customers.map(customer => (
              <div
                key={customer.name}
                className="rounded-2xl bg-slate-900/70 p-3 text-xs"
              >
                <p className="text-slate-200">{customer.quote}</p>
                <p className="mt-2 text-[11px] text-slate-400">
                  {customer.name}  b7 {customer.role}
                </p>
              </div>
            ))}
          </div>
        </div>
        <div className="flex items-center justify-between rounded-2xl border border-slate-800 bg-slate-950/80 px-4 py-3 text-[11px] text-slate-300">
          <span>Siap integrasi dengan Snowflake, BigQuery, dan db lain.</span>
          <span className="rounded-full bg-emerald-500/10 px-2 py-1 text-[10px] font-semibold text-emerald-300">
            SOC2  b7 GDPR
          </span>
        </div>
      </div>
    </div>
  );
}

export default Showcase;
